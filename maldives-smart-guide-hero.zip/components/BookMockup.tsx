import React from 'react';

export const BookMockup: React.FC = () => {
  return (
    <div className="relative group cursor-pointer perspective-1000 w-72 h-[420px] mx-auto md:mx-0">
      <div className="relative w-full h-full transition-transform duration-700 ease-out transform rotate-y-12 group-hover:rotate-y-0 preserve-3d">
        {/* Front Cover */}
        <div className="absolute inset-0 bg-gradient-to-br from-maldives-400 to-maldives-600 rounded-r-lg shadow-2xl flex flex-col items-center justify-between p-8 text-white z-10 border-l border-white/20 overflow-hidden">
          
          {/* Subtle noise texture or pattern */}
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>

          <div className="text-center relative z-10">
            <p className="text-[10px] tracking-[0.4em] uppercase font-medium text-maldives-100 mb-4">The Official</p>
            <h3 className="font-serif text-5xl font-bold leading-none tracking-tight text-white drop-shadow-sm">
              Maldives
            </h3>
            <p className="font-serif text-3xl italic text-yellow-300 mt-1">Smart Guide</p>
          </div>
          
          <div className="w-full flex justify-center py-6 relative z-10">
             {/* Minimalist Palm Icon */}
             <div className="w-32 h-32 rounded-full border border-white/30 flex items-center justify-center bg-white/10 backdrop-blur-sm shadow-inner">
                <svg className="w-16 h-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
             </div>
          </div>

          <div className="text-center relative z-10">
            <div className="w-12 h-0.5 bg-yellow-300 mx-auto mb-4 opacity-70"></div>
            <p className="text-xs font-medium uppercase tracking-widest opacity-90">2025 Budget Edition</p>
          </div>
          
          {/* Glossy sheen */}
          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-white/20 pointer-events-none rounded-r-lg"></div>
        </div>

        {/* Spine */}
        <div className="absolute left-0 top-1 bottom-1 bg-maldives-800 w-5 -translate-x-5 skew-y-6 origin-right shadow-inner opacity-90"></div>
        
        {/* Pages (Side) */}
        <div className="absolute right-0 top-1.5 bottom-1.5 bg-white w-4 -translate-x-[2px] translate-z-[-2px] shadow-sm rounded-r-sm">
          {/* Page lines */}
          <div className="h-full w-full flex flex-col justify-evenly opacity-10">
             {[...Array(20)].map((_, i) => <div key={i} className="h-px bg-black w-full"></div>)}
          </div>
        </div>
        
        {/* Back Cover (Implied for depth) */}
        <div className="absolute inset-0 bg-maldives-800 translate-z-[-18px] rounded-lg shadow-xl translate-x-3"></div>
        
        {/* Soft shadow below book */}
        <div className="absolute -bottom-8 left-10 right-10 h-6 bg-black/20 blur-xl rounded-[100%] transform rotate-y-12 group-hover:rotate-y-0 transition-transform duration-700"></div>
      </div>
    </div>
  );
};