import React, { useState } from 'react';
import { Send, Sparkles, X } from 'lucide-react';
import { askTravelExpert } from '../services/geminiService';

export const AskAI: React.FC = () => {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    setLoading(true);
    setAnswer(null);
    try {
      const response = await askTravelExpert(question);
      setAnswer(response);
    } catch (err) {
      setAnswer("Could not reach the guide right now.");
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) {
    return (
      <button 
        onClick={() => setIsOpen(true)}
        className="mt-10 flex items-center gap-2 text-sm font-medium text-maldives-600 bg-white/50 hover:bg-white border border-maldives-100 hover:border-maldives-200 py-2.5 px-5 rounded-full transition-all duration-300 shadow-sm hover:shadow-md"
      >
        <Sparkles className="w-4 h-4 text-maldives-500" />
        Have a question about the guide? Ask AI Preview
      </button>
    );
  }

  return (
    <div className="mt-8 bg-white/80 backdrop-blur-md border border-maldives-100 rounded-2xl shadow-glow p-5 w-full max-w-md relative overflow-hidden animate-in fade-in slide-in-from-bottom-2">
      
      <div className="flex justify-between items-center mb-4">
        <h4 className="font-semibold text-ocean-900 flex items-center gap-2 text-sm">
          <Sparkles className="w-4 h-4 text-maldives-500" />
          Maldives Budget Expert
        </h4>
        <button 
          onClick={() => setIsOpen(false)} 
          className="text-gray-400 hover:text-gray-600 transition-colors p-1"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {!answer && (
        <form onSubmit={handleSubmit} className="relative group">
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="e.g. How much is the ferry to Maafushi?"
            className="w-full pl-4 pr-12 py-3 bg-white border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-maldives-200 focus:border-maldives-300 text-sm text-gray-800 placeholder-gray-400 transition-all shadow-sm"
            disabled={loading}
          />
          <button
            type="submit"
            disabled={loading || !question.trim()}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-maldives-500 text-white rounded-lg hover:bg-maldives-600 disabled:opacity-50 transition-colors shadow-sm"
          >
            {loading ? (
              <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <Send className="w-3 h-3" />
            )}
          </button>
        </form>
      )}

      {answer && (
        <div className="bg-maldives-50/50 rounded-xl p-4 text-sm text-gray-700 leading-relaxed border border-maldives-100/50">
          <p>{answer}</p>
          <button 
            onClick={() => { setAnswer(null); setQuestion(''); }}
            className="mt-3 text-xs text-maldives-600 font-semibold hover:text-maldives-800 transition-colors flex items-center gap-1"
          >
            <span className="w-4 h-4 rounded-full bg-maldives-100 flex items-center justify-center text-[10px]">+</span>
            Ask another question
          </button>
        </div>
      )}
    </div>
  );
};