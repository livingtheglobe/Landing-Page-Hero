// Fix: Import React to resolve the missing namespace error
import React from 'react';

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface Feature {
  icon: React.ElementType;
  text: string;
}