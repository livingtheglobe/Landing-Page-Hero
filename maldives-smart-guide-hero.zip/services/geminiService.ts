import { GoogleGenAI } from "@google/genai";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API_KEY is missing");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const askTravelExpert = async (question: string): Promise<string> => {
  const ai = getClient();
  if (!ai) return "I'm having trouble connecting to the travel database right now. Please try again later.";

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: question,
      config: {
        systemInstruction: `You are a friendly, expert Maldives budget travel guide author. 
        Your goal is to answer the user's specific question about Maldives travel (costs, transport, islands) briefly and helpfully, 
        BUT you must imply that the full details, comparison charts, and money-saving secrets are inside the "Maldives Smart Guide".
        
        Tone: Enthusiastic, helpful, money-savvy.
        Length: Keep it under 60 words.
        Call to Action: End with a subtle nudge to check the guide for the complete list/chart.
        `,
      },
    });
    
    return response.text || "I couldn't find a specific answer for that, but the guide covers it in detail!";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having a little trouble thinking right now. But believe me, the guide has the answer!";
  }
};
